# Changelog — internal.core

## 1.0.3 — 2026-04-21

- ncs_collector: accept optional tree_path for hierarchical raw layout


## 1.0.2 — 2026-04-21

- Scaffold ncs_configs/ for collection-owned config data


