# Changelog — internal.core

## 1.0.2 — 2026-04-21

- Scaffold ncs_configs/ for collection-owned config data


